# ClawHub Scan Report

Scan ID: skill:teams-hack:1.0.2
Status: succeeded

This archive uses the ClawHub security-audit export shape:

- manifest.json
- clawscan.json
- skillspector.json
- static-analysis.json
- virustotal.json
- README.md
